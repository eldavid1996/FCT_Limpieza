﻿namespace Services.API.Hotel.Core.Dto
{
    // Helped for paginate with filters
    public class PaginationFilterHelped
    {
        public required string Property { get; set; }
        public required string Value { get; set; }
    }
}
