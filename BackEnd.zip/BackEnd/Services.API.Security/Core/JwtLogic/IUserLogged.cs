﻿namespace Services.API.Security.Core.JwtLogic
{
    public interface IUserLogged
    {
        string GetLoggedUser();
    }
}
