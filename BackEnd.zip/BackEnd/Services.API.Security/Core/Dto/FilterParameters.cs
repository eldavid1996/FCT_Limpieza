﻿namespace Services.API.Security.Core.Dto
{
    public class FilterParameters
    {
        public required string Property { get; set; }
        public required string Value { get; set; }
    }
}
