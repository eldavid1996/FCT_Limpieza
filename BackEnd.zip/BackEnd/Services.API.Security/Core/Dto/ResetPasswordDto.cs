﻿namespace Services.API.Security.Core.Dto
{
    public class ResetPasswordDto
    {
        public string newPassword { get; set; }
    }
}
