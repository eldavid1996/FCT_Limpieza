export const  environment = {
    production: false,
    gatewayUrl: 'https://optimistic-knuth.87-106-236-123.plesk.page/api/',
    // hotelUrl: 'https://localhost:8562/',
    // securityUrl: 'https://localhost:8563/'
  }
