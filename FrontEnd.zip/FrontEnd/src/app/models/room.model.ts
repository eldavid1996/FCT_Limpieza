export interface Room {
  Id?: string;
  id?: string;
  RoomNumber: string;
  roomNumber?: string; // for read from json
  Floor: string;
  floor?: string; // for read from json
  Type: string;
  type?: string; // for read from json
  Status: string;
  status?: string; // for read from json
}
