export interface PaginationFilter {
  property: string;
  value: string;
}
