export interface LoginData{
  Email:string;
  Password:string;
}
